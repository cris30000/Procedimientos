// Cargar empleados al iniciar
/*fetch('/empleados')
    .then(res => res.json())
    .then(data => {
        const lista = document.getElementById('listaEmpleados');
        data.forEach(emp => {
            let item = document.createElement('li');
            item.textContent = `${emp.nombre} - ${emp.puesto} - $${emp.salario}`;
            lista.appendChild(item);
        });
    });*/

// Agregar empleado
document.getElementById('formEmpleado').addEventListener('submit', e => {
    e.preventDefault();

    const data = {
        nombre: document.getElementById('nombre').value,
        puesto: document.getElementById('puesto').value,
        salario: document.getElementById('salario').value
    };

    fetch('/empleados', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(msg => {
        alert(msg.mensaje);
        location.reload();
    });
});


fetch('/empleados')
    .then(res => res.json())
    .then(data => {
        const lista = document.getElementById('listaEmpleados');
        lista.innerHTML = "";

        data.forEach(emp => {
            let item = document.createElement('li');
            item.innerHTML = `
                ${emp.nombre} - ${emp.puesto} - $${emp.salario}
                <button onclick="eliminarEmpleado(${emp.id})">Eliminar</button>
                <button onclick="editarEmpleado(${emp.id}, '${emp.nombre}', '${emp.puesto}', ${emp.salario})">Editar</button>
            `;
            lista.appendChild(item);
        });
    });


    function eliminarEmpleado(id) {
    if (!confirm("¿Seguro que deseas eliminar este empleado?")) return;

    fetch(`/empleados/${id}`, {
        method: 'DELETE'
    })
    .then(res => res.json())
    .then(msg => {
        alert(msg.mensaje);
        location.reload();
    });
}

function editarEmpleado(id, nombre, puesto, salario) {
    document.getElementById('nombre').value = nombre;
    document.getElementById('puesto').value = puesto;
    document.getElementById('salario').value = salario;

    // Cambiar comportamiento del botón
    const form = document.getElementById('formEmpleado');
    form.onsubmit = (e) => {
        e.preventDefault();

        const data = {
            nombre: document.getElementById('nombre').value,
            puesto: document.getElementById('puesto').value,
            salario: document.getElementById('salario').value
        };

        fetch(`/empleados/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(msg => {
            alert(msg.mensaje);
            location.reload();
        });

    };
    
}
