const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./db'); // Tu conexión a MySQL

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Función auxiliar para ejecutar queries con promesas
const queryAsync = (sql, params = []) => {
    return new Promise((resolve, reject) => {
        db.query(sql, params, (err, results) => {
            if (err) reject(err);
            else resolve(results);
        });
    });
};

// ---------------------------
// RUTAS
// ---------------------------

// Obtener todos los empleados
app.get('/empleados', async (req, res) => {
    try {
        const results = await queryAsync("CALL sp_listar_empleados()");
        res.status(200).json(results[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ mensaje: "Error al obtener empleados" });
    }
});

// Insertar nuevo empleado
app.post('/empleados', async (req, res) => {
    const { nombre, puesto, salario } = req.body;

    if (!nombre || !puesto || !salario) {
        return res.status(400).json({ mensaje: "Faltan datos obligatorios" });
    }

    try {
        await queryAsync("CALL sp_insertar_empleado(?, ?, ?)", [nombre, puesto, salario]);
        res.status(201).json({ mensaje: "Empleado agregado" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ mensaje: "Error al agregar empleado" });
    }
});

// Actualizar empleado
app.put('/empleados/:id', async (req, res) => {
    const { id } = req.params;
    const { nombre, puesto, salario } = req.body;

    if (!nombre || !puesto || !salario) {
        return res.status(400).json({ mensaje: "Faltan datos obligatorios" });
    }

    try {
        await queryAsync("CALL sp_actualizar_empleado(?, ?, ?, ?)", [id, nombre, puesto, salario]);
        res.status(200).json({ mensaje: "Empleado actualizado" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ mensaje: "Error al actualizar empleado" });
    }
});

// Eliminar empleado
app.delete('/empleados/:id', async (req, res) => {
    const { id } = req.params;

    try {
        await queryAsync("CALL sp_eliminar_empleado(?)", [id]);
        res.status(200).json({ mensaje: "Empleado eliminado" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ mensaje: "Error al eliminar empleado" });
    }
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});
