const mysql = require('mysql2');

const conexion = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',   // tu contraseña de MySQL
    database: 'empleados_db'
});

conexion.connect(err => {
    if (err) throw err;
    console.log("Conexión a MySQL exitosa");
});

module.exports = conexion;
