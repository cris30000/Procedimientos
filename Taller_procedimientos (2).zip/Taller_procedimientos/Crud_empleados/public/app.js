const API_URL = "http://localhost:3000/api/empleados";

let editando = false;   // indica si estamos editando
let idEditar = null;    // guarda el id del empleado que se edita

// Cargar empleados al iniciar
document.addEventListener("DOMContentLoaded", cargarEmpleados);

// ==================== CARGAR EMPLEADOS ====================
function cargarEmpleados() {
  fetch(API_URL)
    .then(res => res.json())
    .then(data => {
      const tabla = document.getElementById("tabla-empleados");
      tabla.innerHTML = "";

      data.forEach(emp => {
        tabla.innerHTML += `
          <tr>
            <td>${emp.id}</td>
            <td>${emp.nombre}</td>
            <td>${emp.puesto}</td>
            <td>${emp.salario}</td>
            <td>
              <button class="editar" onclick="editarEmpleado(${emp.id}, \`${emp.nombre}\`, \`${emp.puesto}\`, ${emp.salario})">Editar</button>
              <button class="eliminar" onclick="eliminarEmpleado(${emp.id})">Eliminar</button>
            </td>
          </tr>`;
      });
    });
}

// ==================== GUARDAR O ACTUALIZAR EMPLEADO ====================
function guardarEmpleado() {
    const nombre = document.getElementById("nombre").value.trim();
    const puesto = document.getElementById("puesto").value.trim();
    const salario = parseFloat(document.getElementById("salario").value);  // <--- AQUÍ

    if (!nombre || !puesto || isNaN(salario)) {
        alert("Todos los campos son obligatorios y el salario debe ser un número");
        return;
    }

    const empleado = { nombre, puesto, salario };

    if (!editando) {
        // CREAR NUEVO
        fetch("http://localhost:3000/api/empleados", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(empleado)
        })
        .then(res => res.json())
        .then(() => {
            limpiarFormulario();
            cargarEmpleados();
        });

    } else {
        // ACTUALIZAR
        fetch(`http://localhost:3000/api/empleados/${idEditar}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(empleado)
        })
        .then(res => res.json())
        .then(() => {
            cancelarEdicion();
            cargarEmpleados();
        });
    }
}


// ==================== EDITAR EMPLEADO ====================
function editarEmpleado(id, nombre, puesto, salario) {
  editando = true;
  idEditar = id;

  document.getElementById("nombre").value = nombre;
  document.getElementById("puesto").value = puesto;
  document.getElementById("salario").value = salario;

  document.getElementById("form-title").innerText = "Editar Empleado";
  document.getElementById("guardarBtn").innerText = "Actualizar";
  document.getElementById("cancelarBtn").classList.remove("hidden");

  console.log("Editando ID:", idEditar); // Verificar que llega el id correcto
}

// ==================== CANCELAR EDICION ====================
function cancelarEdicion() {
  editando = false;
  idEditar = null;

  limpiarFormulario();
  document.getElementById("form-title").innerText = "Agregar Empleado";
  document.getElementById("guardarBtn").innerText = "Guardar";
  document.getElementById("cancelarBtn").classList.add("hidden");
}

// ==================== ELIMINAR EMPLEADO ====================
function eliminarEmpleado(id) {
  if (!confirm("¿Seguro que deseas eliminar este empleado?")) return;

  fetch(`${API_URL}/${id}`, {
    method: "DELETE",
  })
    .then(res => res.json())
    .then(() => cargarEmpleados());
}

// ==================== LIMPIAR FORMULARIO ====================
function limpiarFormulario() {
  document.getElementById("nombre").value = "";
  document.getElementById("puesto").value = "";
  document.getElementById("salario").value = "";
}
