/*const db = require('../config/db');

module.exports = {
    lista(req, res) {
        db.query('SELECT * FROM empleados', (err, resultados) => {
            if(err) throw err;
            res.json(resultados);
        });
    },

    crear(req, res) {
        const datos = req.body;
        db.query('INSERT INTO empleados SET ?', datos, (err, resultado) => {
            if(err) throw err;
            res.json({ mensaje: 'Empleado agregado', id: resultado.insertId });
        });
    },

    actualizar(req, res) {
        const id = req.params.id;
        const datos = req.body;
        db.query('UPDATE empleados SET ? WHERE id = ?', [datos, id], (err) => {
            if(err) throw err;
            res.json({ mensaje: 'Empleado actualizado' });
        });
    },

    eliminar(req, res) {
        const id = req.params.id;
        db.query('DELETE FROM empleados WHERE id = ?', id, (err) => {
            if(err) throw err;
            res.json({ mensaje: 'Empleado eliminado' });
        });
    }
};*/

const db = require('../config/db');

module.exports = {

    // LISTAR EMPLEADOS
    lista(req, res) {
        db.query("CALL sp_listar_empleados()", (err, resultado) => {
            if (err) throw err;
            res.json(resultado[0]);  // Resultado real está en [0]
        });
    },

    // INSERTAR EMPLEADO
    crear(req, res) {
        const { nombre, puesto, salario } = req.body;

        db.query(
            "CALL sp_insertar_empleado(?, ?, ?)",
            [nombre, puesto, salario],
            (err, result) => {
                if (err) throw err;
                res.json({ mensaje: "Empleado agregado correctamente" });
            }
        );
    },

    // ACTUALIZAR EMPLEADO
    actualizar(req, res) {
        const id = req.params.id;
        const { nombre, puesto, salario } = req.body;

        db.query(
            "CALL sp_actualizar_empleado(?, ?, ?, ?)",
            [id, nombre, puesto, salario],
            (err) => {
                if (err) throw err;
                res.json({ mensaje: "Empleado actualizado" });
            }
        );
    },

    // ELIMINAR EMPLEADO
    eliminar(req, res) {
        const id = req.params.id;

        db.query(
            "CALL sp_eliminar_empleado(?)",
            [id],
            (err) => {
                if (err) throw err;
                res.json({ mensaje: "Empleado eliminado" });
            }
        );
    }

};

