const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// AQUÍ VA ESTA LÍNEA ⬇⬇⬇⬇
const empleadosRoutes = require('./routes/empleados');

// Y AQUÍ SE USA ⬇⬇⬇⬇
app.use('/api/empleados', empleadosRoutes);

app.listen(3000, () => {
    console.log('Servidor ejecutándose en http://localhost:3000');
});
