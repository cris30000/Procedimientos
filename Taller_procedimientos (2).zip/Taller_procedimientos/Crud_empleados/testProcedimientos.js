const db = require('./config/db'); // Ajusta esta ruta si es necesario

// Función para probar actualización
function probarActualizarEmpleado() {
  const id = 1; // Cambia al id que quieras probar
  const nombre = 'Juan Pérez';
  const puesto = 'Gerente';
  const salario = 2000.00;

  db.query(
    "CALL sp_actualizar_empleado(?, ?, ?, ?)",
    [id, nombre, puesto, salario],
    (err, results) => {
      if (err) {
        console.error('Error al actualizar empleado:', err);
      } else {
        console.log('Empleado actualizado correctamente.');
      }
      db.end(); // Cierra conexión después de la prueba
    }
  );
}

// Función para probar eliminación
function probarEliminarEmpleado() {
  const id = 1; // Cambia al id que quieras eliminar

  db.query(
    "CALL sp_eliminar_empleado(?)",
    [id],
    (err, results) => {
      if (err) {
        console.error('Error al eliminar empleado:', err);
      } else {
        console.log('Empleado eliminado correctamente.');
      }
      db.end(); // Cierra conexión después de la prueba
    }
  );
}

// Llama a la función que quieras probar
// probarActualizarEmpleado();
probarEliminarEmpleado();
