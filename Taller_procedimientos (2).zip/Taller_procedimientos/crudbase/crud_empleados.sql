CREATE DATABASE empleados_db;

USE empleados_db;

CREATE TABLE empleados (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100),
  puesto VARCHAR(100),
  salario DECIMAL(10,2)
);
