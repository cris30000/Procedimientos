
-- procedimiento : obtener todos los empleados
DELIMITER $$

CREATE PROCEDURE sp_listar_empleados()
BEGIN
    SELECT * FROM empleados;
END $$

DELIMITER ;

-- procedimiento : obtener insertar  empleados


DELIMITER $$

CREATE PROCEDURE sp_insertar_empleado(
    IN p_nombre VARCHAR(100),
    IN p_puesto VARCHAR(100),
    IN p_salario DECIMAL(10,2)
)
BEGIN
    INSERT INTO empleados(nombre, puesto, salario)
    VALUES (p_nombre, p_puesto, p_salario);
END $$

DELIMITER ;




-- procedimiento : actualizar  empleados
DELIMITER $$

CREATE PROCEDURE sp_actualizar_empleado(
    IN p_id INT,
    IN p_nombre VARCHAR(100),
    IN p_puesto VARCHAR(100),
    IN p_salario DECIMAL(10,2)
)
BEGIN
    UPDATE empleados
    SET nombre = p_nombre,
        puesto = p_puesto,
        salario = p_salario
    WHERE id = p_id;
END $$

DELIMITER ;

-- eliminar empleado
DELIMITER $$

CREATE PROCEDURE sp_eliminar_empleado(
    IN p_id INT
)
BEGIN
    DELETE FROM empleados WHERE id = p_id;
END $$

DELIMITER ;

-- ejecuto para comprobar los procedimientos

CALL sp_listar_empleados();

SHOW PROCEDURE STATUS WHERE Name = 'sp_insertar_empleado';

DELIMITER $$

CREATE PROCEDURE sp_insertar_empleado(
    IN p_nombre VARCHAR(100),
    IN p_puesto VARCHAR(100),
    IN p_salario DECIMAL(10,2)
)
BEGIN
    INSERT INTO empleados(nombre, puesto, salario)
    VALUES (p_nombre, p_puesto, p_salario);
END $$

DELIMITER ;
CALL sp_insertar_empleado('Juan', 'Gerente', 1500);



