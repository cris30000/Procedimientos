-- procedimiento almacenado con parametros

DELIMITER //

CREATE PROCEDURE todos_empleados()
BEGIN

	SELECT * FROM empleados;
END//
DELIMITER ;

CALL todos_empleados;
