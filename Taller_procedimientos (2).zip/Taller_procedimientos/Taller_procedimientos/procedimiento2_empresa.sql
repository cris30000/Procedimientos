-- creamos procedimiento con parametros de entrada

DELIMITER //

CREATE PROCEDURE empleado_porSalario (IN SalarioConfirmado DECIMAL(10,2))

BEGIN

 SELECT Nombre_empleado,Salario
 FROM empleados
 WHERE salario>=SalarioConfirmado;
 
END //
DELIMITER ; 

-- INVOCAMOS EL PROCEDIMIENTO ASUMIENDO UN PARAMETRO DE ENTRADA salario Confirmado es =1.950.000
CALL empleado_porSalario(1950000);