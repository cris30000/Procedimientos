-- insertamos datos a la tabla empleados de empresa

INSERT INTO empleados(
id_empleado,Nombre_empleado,Apellido_empleado,Direccion_empleado,Salario)
VALUES

(1, 'Carlos', 'Ramírez', 'Av. Siempre Viva 123, Ciudad de México', 1850000),
(2, 'María', 'González', 'Calle Los Pinos 45, Guadalajara', 2100000),
(3, 'José', 'Martínez', 'Boulevard del Sol 980, Monterrey', 1720000),
(4, 'Laura', 'Fernández', 'Av. Libertad 256, Puebla', 1950000),
(5, 'Andrés', 'Torres', 'Calle Olmos 12, Querétaro', 2250000);