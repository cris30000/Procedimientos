-- CREAMOS LA DATA PARA BD

INSERT INTO empleados(
id_empleado,Nombre_empleado,Salario)
VALUES
(1,"Cristina",5000000),
(2,"Daniela",3000000),
(3,"Maria",4500000),
(4,"Daniel",2800000),
(5,"Diego",2500000);