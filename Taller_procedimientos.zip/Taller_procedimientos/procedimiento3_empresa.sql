-- creamos procedimiento con parametros de salida


DELIMITER //

CREATE PROCEDURE contar_Empleados( IN empleado_id INT, OUT total_empleado INT)
	BEGIN
    -- CONSULTA SQL PARA CONTAR  Y ASIGNAR  EL RESULTADO A LA VARIABLE OUT
    
    SELECT 
    COUNT(*)
    INTO
    total_empleado
    FROM empleados
    WHERE
    id_empleado=empleado_id;
    END //
    DELIMITER ;
    
    
    
    SET @conteo=0;
    
    CALL contar_Empleados(1,@conteo);
    
    SELECT @conteo as "Empleado 1";