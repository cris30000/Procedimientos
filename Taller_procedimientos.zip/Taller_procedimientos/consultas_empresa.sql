-- CONSULTAS

SELECT * FROM empleados;