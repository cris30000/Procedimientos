-- creamos base de datos para empresa

CREATE DATABASE IF NOT EXISTS empresa;
USE empresa;
 
 
 
 
 CREATE TABLE IF NOT EXISTS empleados(
 id_empleado INT UNIQUE NOT NULL PRIMARY KEY,
 Nombre_empleado VARCHAR(50) NOT NULL,
 Apellido_empleado VARCHAR(50) NOT NULL,
 Direccion_empleado VARCHAR(50) NOT NULL,
 Salario DECIMAL(10,2)
 );